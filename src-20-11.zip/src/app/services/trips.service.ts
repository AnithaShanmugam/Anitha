import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable, throwError, BehaviorSubject, of } from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse, HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TripsService {

   public headers = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Origin , Access-Control-* , X-Requested-With, Accept',
      'Content-Type': 'application/json,charset=utf-8',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, HEAD'
    });
    config = environment;
  
    constructor(private httpClient: HttpClient) {
    }
 
   public getAllTrips() {

      return this.httpClient.get<any>(`${this.config.apiUrl}/getAllTrips`, { headers: this.headers })
        .pipe(map(data => {
          console.log(data);
          if (data != null) {
            return of(new HttpResponse({ status: 200, body: data }));
          } else {
            // return false to indicate failed login
            return throwError({ error: { message: 'Please check your details' } });
          }
        }),
          //  catchError(this.handleError)
        );
    }

    public getTripsByUser(userId: number) {

      return this.httpClient.get<any>(`${this.config.apiUrl}/getTripsbyId/`+userId, { headers: this.headers })
        .pipe(map(data => {
          console.log(data);
          if (data != null) {
            return of(new HttpResponse({ status: 200, body: data }));
          } else {
            // return false to indicate failed login
            return throwError({ error: { message: 'Please check your details' } });
          }
        }),
          //  catchError(this.handleError)
        );
    }
   
}
