import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { LoginModel } from '../models/login-model';
import { Observable, throwError, BehaviorSubject , of} from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse ,HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS} from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {

  private currentUserSubject: BehaviorSubject<LoginModel>;
  public currentUser: Observable<LoginModel>;
  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  public headers = new HttpHeaders({  
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Origin , Access-Control-* , X-Requested-With, Accept',
    'Content-Type':  'application/json,charset=utf-8',    
    'Access-Control-Allow-Methods' : 'GET, POST, PUT, DELETE, OPTIONS, HEAD' });
  config = environment;

  constructor(private httpClient: HttpClient) {
   
  } 


  public login(loginmodel: LoginModel) {
    return this.httpClient.post<any>(`${this.config.apiUrl}/logIn`, loginmodel, {headers:this.headers})
      .pipe(map(data => {
        console.log(data);

        if (data.employeeToken != null) {
          localStorage.setItem('usertype', data.userType);
          localStorage.setItem('userId', data.userId);
          if (data.userType === 1) {
            // store username and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser', 'admin');            
            localStorage.setItem('employeeId', data.userId);
            localStorage.setItem('AdminUser',
              JSON.stringify({
                username: loginmodel.UserName, token: data.employeeToken, UserId: data.userId,
                usertype: 'Admin', firstName: data.fullName
              }));
              return of(new HttpResponse({ status: 200, body: data }));
          } else if (data.userType === 2) {
            // store username and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser',
              JSON.stringify({
                username: loginmodel.UserName, token: data.employeeToken, usertype: 'user', UserId: data.userId,
                firstName: data.fullName
              }));
              return of(new HttpResponse({ status: 200, body: data }));
          } else if (data.userType === 3) {
            // store username and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('userType', 'guest');
            localStorage.setItem('employeeId', data.userId);
            localStorage.setItem('guestUser',
              JSON.stringify({
                username: loginmodel.UserName, token: data.employeeToken, usertype: 'guest', UserId: data.userId,
                firstName: data.fullName
              }));
              return of(new HttpResponse({ status: 200, body: data }));
          }          
          
          return data;
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your input' } });
        }
      }),
        //catchError(this.handleError)
      );
  }

  logout() {
    localStorage.removeItem('currentUser');    
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  };

}
