import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { LoginModel } from '../models/login-model';
import { Observable, throwError, BehaviorSubject, of } from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse, HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';

import { environment } from '../../environments/environment';
import { VehicleDetail } from '../models/vehicle-details';
import { BookRide } from '../models/book-ride';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  private currentUserSubject: BehaviorSubject<LoginModel>;
  public currentUser: Observable<LoginModel>;
  public headers = new HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Origin , Access-Control-* , X-Requested-With, Accept',
    'Content-Type': 'application/json,charset=utf-8',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, HEAD'
  });
  config = environment;

  constructor(private httpClient: HttpClient) {
  }

  public register(loginmodel: LoginModel): Observable<any> {
    loginmodel.EmployeeToken = '1'
    loginmodel.Contact = Number(loginmodel.Contact);
    loginmodel.UserType = Number(loginmodel.UserType);
    return this.httpClient.post<any>(`${this.config.apiUrl}/registerUser/`, loginmodel, { headers: this.headers })
      .pipe(map(data => {
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
          //return data;
        } else {
          // return false to indicate failed login        
          return throwError({ error: { message: 'Please check your input' } });
        }
      }),
        //   catchError(this.handleError)
      );
  }


  public bookRide(bookRide: BookRide) {   
    bookRide.Amount = 100;
    bookRide.IsConfirmed = '1';
    bookRide.Status = 'Open';
    bookRide.IsCancelled = '0';
    bookRide.VehicleId =1;
    bookRide.UserId = localStorage.getItem('employeeId');

    return this.httpClient.post<any>(`${this.config.apiUrl}/bookRide`, bookRide, { headers: this.headers })
      .pipe(map(data => {
        console.log(data);
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your details' } });
        }
      }),
        //  catchError(this.handleError)
      );
  }

  public registerVehicle(vehicleDetail: VehicleDetail) {

    return this.httpClient.post<any>(`${this.config.apiUrl}/registerVehicle`, vehicleDetail, { headers: this.headers })
      .pipe(map(data => {
        console.log(data);
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your details' } });
        }
      }),
        //  catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  };

}
