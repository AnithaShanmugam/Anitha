import { Component} from '@angular/core';

@Component({
    templateUrl:'./user-dashboard.component.html'
    ,styleUrls: ['./../_layout/admin-layout.component.css']
})

export class UserDashboardComponent
{

}