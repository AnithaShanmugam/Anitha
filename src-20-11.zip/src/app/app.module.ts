import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth-guard/auth.guard';
import { AuthenticationService } from '../app/services/authentication.service';
import { TripsComponent } from './trips/trips.component';
import { AlertComponent } from '../app/alert/alert.component';
import { ErrorInterceptor } from '../app/helpers/error.interceptor'
import { AppAdminLayoutComponent } from './_layout/admin-layout.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AppUserLayoutComponent } from './_layout/user-layout.component';
import { CustomMaterialModule } from './core/material.module';
import { RegisterUserComponent } from './login/user-register.component'
import { RegisterVehicleComponent } from './vehicle-register/vehicle-register.component';
import { BookRideComponent } from './book-ride/book-ride.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    LoginComponent,
    TripsComponent,
    AlertComponent,
    AppAdminLayoutComponent,
    AppUserLayoutComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    RegisterUserComponent,
    RegisterVehicleComponent,
    BookRideComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    FormsModule,
    CustomMaterialModule,
    RouterModule.forRoot([
      //{ path: '', component: HomeComponent, pathMatch: 'full' },
      // { path: '', component: LoginComponent },
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterUserComponent },
      { path: 'trips', component: TripsComponent, canActivate: [AuthGuard] },
      {
        path: 'admin',
        component: AppAdminLayoutComponent,
        children: [
          { path: 'dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard] },
          { path: 'trips', component: TripsComponent, canActivate: [AuthGuard] },
          { path: 'vehicle-register', component: RegisterVehicleComponent },
          { path: 'book-ride', component: BookRideComponent, canActivate: [AuthGuard] }
          // { path: 'trip', component: TripListComponent, canActivate: [AdminAuthGuardService] },
          // { path: 'manageusers', component: ManageusersComponent, canActivate: [AdminAuthGuardService] }
        ]
      },
      {
        path: 'user',
        component: AppUserLayoutComponent,
        children: [
          { path: 'dashboard', component: UserDashboardComponent, canActivate: [AuthGuard] },
          { path: 'vehicle-register', component: RegisterVehicleComponent },
          { path: 'trips', component: TripsComponent, canActivate: [AuthGuard] },
          { path: 'book-ride', component: BookRideComponent, canActivate: [AuthGuard] }
          // { path: 'trip', component: TripListComponent, canActivate: [UserAuthGuardService] },          
          // { path: 'vehicleregister', component: VehicleRegisterComponent, canActivate: [UserAuthGuardService] }
        ]
      },
      {
        path: 'guest',
        component: AppUserLayoutComponent,
        children: [
          { path: 'dashboard', component: UserDashboardComponent, canActivate: [AuthGuard] },                    
          { path: 'book-ride', component: BookRideComponent, canActivate: [AuthGuard] },
          { path: 'trips', component: TripsComponent, canActivate: [AuthGuard] }
          // { path: 'trip', component: TripListComponent, canActivate: [UserAuthGuardService] },          
          // { path: 'vehicleregister', component: VehicleRegisterComponent, canActivate: [UserAuthGuardService] }
        ]
      }
    ])
  ],
  providers: [
    AuthenticationService, AuthGuard,
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
