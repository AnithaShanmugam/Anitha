import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthenticationService } from '../services/authentication.service';
import { AlertService } from '../services/alert.service';
import { LoginModel } from '../models/login-model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  returnUrl: string = '';
  loading = false;
  LoginModel: LoginModel = new LoginModel();
  //private _loginservice;

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router,
    private loginservice: AuthenticationService, private alertService: AlertService) {

    localStorage.removeItem('currentUser');
    localStorage.removeItem('userType');
  }

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
    this.loginservice.logout();
    //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  get f() { return this.loginForm.controls; }


  onSubmit() {
    this.submitted = true;
    this.alertService.clear();

    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.loginservice.login(this.loginForm.value)
    .pipe(first())
      .subscribe(
        response => {
          if (response.value.body.userType == "1") {
            this.alertService.success('Login successful', true);
            this.router.navigate(['/admin/dashboard']);
          } else if (response.value.body.userType == "2") {
            this.alertService.success('Login successful', true);
            this.router.navigate(['/user/dashboard']);
          } else if (response.value.body.userType == "3") {
            this.alertService.success('Login successful', true);
            this.router.navigate(['/guest/dashboard']);
          }
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
    //TODO : to be removed after service api integrated and be sure to set in local storage
    // localStorage.setItem('currentUser', 'admin');
    // localStorage.setItem('employeeId', '1');
    // localStorage.setItem('AdminUser',
    // JSON.stringify({
    //   username: 'admin', token: '23424234', usertype: 'Admin', UserId: 11111,
    //   firstName: 'Anitha', lastName: 'S'
    // }));

    // localStorage.setItem('userType', 'guest');
    // localStorage.setItem('currentUser',
    //   JSON.stringify({
    //     username: 'admin', token: '23424234', usertype: 'guest', UserId: 11111,
    //     firstName: 'Anitha', lastName: 'S'
    //   }));
    // //this.router.navigate(['/admin/dashboard']);
    // //this.router.navigate(['/user/dashboard']);
    // this.router.navigate(['/guest/dashboard']);
  }
}
