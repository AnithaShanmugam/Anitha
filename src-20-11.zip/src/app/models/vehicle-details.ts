
export class VehicleDetail {
    firstName: string;
    lastName: string;
    registrationNo: number;
    vehicleType: string;
    idProof: string;
    contact: string;
    email: string;
}
 