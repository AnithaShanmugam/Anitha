
export class TripDetailsModel {
    public TripID: number;
    public VehicleId: number;
    public employeeId: number;
    public Source: string;
    public Destination: string;
    public StartTime: Date;
    public EndTime: Date;
    public TripTakenBy: string;
    public UserId: number;
    public TotalDistance: number;
    public Fare: number;
    public Status: string;
}