
export class BookRide {
    Pickup: string;
    Drop: string;
    StartDateTime: Date;
    EndDateTime: Date;
    VehicleType: string;
    Contact: string;
    Amount: number;    
    VehicleId: number;
    Status: string;
    IsConfirmed: string;
    IsCancelled: string;
    UserId: string;
}
