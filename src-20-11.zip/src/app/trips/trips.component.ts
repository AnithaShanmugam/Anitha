import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { TripsService } from '../services/trips.service';
import { AlertService } from '../services/alert.service';

@Component({
  selector: 'app-trips',
  templateUrl: './trips.component.html',
  styleUrls: ['./trips.component.css']
})
export class TripsComponent implements OnInit {

  trips: any;
  userType: string = '';
  loading = false;

  constructor(private route: Router, private service: TripsService, private alertService: AlertService) { }

  ngOnInit() {
    if (localStorage.getItem('usertype') === '1') {
      this.userType = 'ADMIN';
      this.getAllTrips();
    }
    else if (localStorage.getItem('userType') === '2' || localStorage.getItem('userType') === '3') {
      this.userType = localStorage.getItem('currentUser');
      this.getTripsByEmployeeId();
    }
    else {
      localStorage.removeItem('userType');
      localStorage.removeItem('currentUser');
      localStorage.removeItem('employeeId');
      this.route.navigate(['/login']);
    }
  }


  getAllTrips() {
    this.trips = [];
    this.service.getAllTrips()
      .pipe(first())
      .subscribe(
        data => {
          this.alertService.success('All Trip Details retrieved successfully', true);
          this.loading = false;
          this.trips = data.value.body;
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

  getTripsByEmployeeId() {
    this.trips = [];
    const userId: any = localStorage.getItem('userId');
    this.service.getTripsByUser(userId).pipe(first())
      .subscribe(
        data => {
          this.alertService.success('Trip Details retrieved successfully', true);
          this.loading = false;
          this.trips = data.value.body;
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

}
