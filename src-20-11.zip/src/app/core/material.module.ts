import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatButtonModule,MatSnackBarModule,MatFormFieldModule,MatInputModule, MatProgressSpinnerModule
  ,MatTableModule,MatNativeDateModule
  , MatIconModule, MatSidenavModule
, MatListModule, MatToolbarModule
, MatCardModule, MatDialogModule} from '@angular/material';

@NgModule({
  imports: [CommonModule,MatProgressSpinnerModule,MatSnackBarModule,MatInputModule,MatFormFieldModule,MatTableModule,MatDialogModule, MatButtonModule,MatToolbarModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule, MatCardModule],
  exports: [CommonModule, MatProgressSpinnerModule,MatSnackBarModule,MatInputModule,MatFormFieldModule,MatTableModule, MatDialogModule,MatButtonModule, MatToolbarModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule, MatCardModule],
})
export class CustomMaterialModule { }
