import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { UserService } from '../services/user-service';
import { AlertService } from '../services/alert.service';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {

  users: any;
  userType: string = '';
  loading = false;
  userId: number;
  constructor(private route: Router, private service: UserService, private alertService: AlertService) { }

  ngOnInit() {
    this.userId = localStorage.getItem('userId') ? Number(localStorage.getItem('userId')) : 0;

    if (localStorage.getItem('usertype') === '1') {
      this.userType = 'ADMIN';
      this.getAllUser();
    }        
  }


  getAllUser() {
    this.users = [];
    this.service.getAllUser()
      .pipe(first())
      .subscribe(
        data => {
          this.alertService.success('All Trip Details retrieved successfully', true);
          this.loading = false;
          this.users = data.value.body;
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

}
