import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthenticationService } from '../services/authentication.service';
import { UserService } from '../services/user-service';
import { AlertService } from '../services/alert.service';

@Component({
    templateUrl: 'book-ride.component.html'
})

export class BookRideComponent implements OnInit {
    bookRideForm: FormGroup;
    loading = false;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private authenticationService: AuthenticationService,
        private userService: UserService,
        private alertService: AlertService
    ) {
        // redirect to home if already logged in
        // if (this.authenticationService.currentUserValue) {
        //     this.router.navigate(['/']);
        // }
    }

    ngOnInit() {
        this.bookRideForm = this.formBuilder.group({
            Pickup: ['', Validators.required],
            Drop: ['', Validators.required],
            StartDateTime: ['', Validators.required],
            EndDateTime: ['', Validators.required],
            VehicleType: ['', [Validators.required]],
            Contact: ['', Validators.required]

        });
    }



    // convenience getter for easy access to form fields
    get f() { return this.bookRideForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.bookRideForm.invalid) {
            return;
        }

        this.loading = true;
        this.userService.bookRide(this.bookRideForm.value)
            .pipe(first())
            .subscribe(
                data => {
                    this.alertService.success('Booking successful', true);
                    this.loading = false;
                    if (localStorage.getItem('usertype') === "1") {
                        this.router.navigate(['/admin/trips']);
                    } else if (localStorage.getItem('usertype') === "2") {
                        this.router.navigate(['/user/trips']);
                    } else {
                        this.router.navigate(['/guest/trips']);
                    }
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                });
    }
}