// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Router } from '@angular/router';
// import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { NO_ERRORS_SCHEMA } from '@angular/compiler/src/core';

// import { RegisterUserComponent } from './user-register.component';
// import { UserService } from '../services/user-service';
// import { AlertService } from '../services/alert.service';

// class ServiceMock {

// }

// describe('RegisterUserComponent', () => {
//   let component: RegisterUserComponent;
//   let fixture: ComponentFixture<RegisterUserComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [RegisterUserComponent],
//       imports: [ReactiveFormsModule, CommonModule],
//       schemas: [NO_ERRORS_SCHEMA],      
//       providers: [{ provide: UserService, useClass: ServiceMock },
//       { provide: AlertService, useClass: ServiceMock }]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RegisterUserComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
