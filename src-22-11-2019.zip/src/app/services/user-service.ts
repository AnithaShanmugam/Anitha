import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { LoginModel } from '../models/login-model';
import { Observable, throwError, BehaviorSubject, of } from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse, HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';

import { environment } from '../../environments/environment';
import { VehicleDetail } from '../models/vehicle-details';
import { BookRide } from '../models/book-ride';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  private currentUserSubject: BehaviorSubject<LoginModel>;
  public currentUser: Observable<LoginModel>;
  public headers = new HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Origin , Access-Control-* , X-Requested-With, Accept',
    'Content-Type': 'application/json,charset=utf-8',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, HEAD'
  });
  config = environment;

  constructor(private httpClient: HttpClient) {
  }

  public register(loginmodel: LoginModel): Observable<any> {
    loginmodel.EmployeeToken = '1'
    loginmodel.Contact = Number(loginmodel.Contact);
    loginmodel.UserType = Number(loginmodel.UserType);
    return this.httpClient.post<any>(`${this.config.apiUrl}/registerUser/`, loginmodel, { headers: this.headers })
      .pipe(map(data => {
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
          //return data;
        } else {
          // return false to indicate failed login        
          return throwError({ error: { message: 'Please check your input' } });
        }
      }),        
      );
  }


  public bookRide(bookRide: BookRide) {   
    bookRide.Amount = 100;
    bookRide.IsConfirmed = false;
    bookRide.Status = 'Open';
    bookRide.IsCancelled = false;
    bookRide.VehicleId =1;
    bookRide.Contact = Number(bookRide.Contact);
    bookRide.UserId = Number(localStorage.getItem('employeeId'));

    return this.httpClient.post<any>(`${this.config.apiUrl}/bookRide`, bookRide, { headers: this.headers })
      .pipe(map(data => {
        console.log(data);
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your details' } });
        }
      }),
        //  catchError(this.handleError)
      );
  }

  public registerVehicle(vehicleDetail: VehicleDetail) {

    return this.httpClient.post<any>(`${this.config.apiUrl}/registerVehicle`, vehicleDetail, { headers: this.headers })
      .pipe(map(data => {
        console.log(data);
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your details' } });
        }
      }),
        //  catchError(this.handleError)
      );
  } 

  public getAllUser():Observable<any> {

    return this.httpClient.get<any>(`${this.config.apiUrl}/getAllUsers`, { headers: this.headers })
      .pipe(map(data => {
        console.log(data);
        if (data != null) {
          return of(new HttpResponse({ status: 200, body: data }));
        } else {
          // return false to indicate failed login
          return throwError({ error: { message: 'Please check your details' } });
        }
      }),
        //  catchError(this.handleError)
      );
  } 

}
