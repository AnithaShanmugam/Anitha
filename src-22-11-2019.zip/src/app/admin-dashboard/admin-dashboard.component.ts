import { Component} from '@angular/core';

@Component({
    templateUrl:'./admin-dashboard.component.html',
    styleUrls: ['../_layout/admin-layout.component.css']
})

export class AdminDashboardComponent
{


}