import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { TripsService } from '../services/trips.service';
import { AlertService } from '../services/alert.service';

@Component({
  selector: 'app-trips',
  templateUrl: './trips.component.html',
  styleUrls: ['./trips.component.css']
})
export class TripsComponent implements OnInit {

  trips: any;
  userType: string = '';
  loading = false;
  userId: number;
  constructor(private route: Router, private service: TripsService, private alertService: AlertService) { }

  ngOnInit() {
    this.userId = localStorage.getItem('userId') ? Number(localStorage.getItem('userId')) : 0;

    if (localStorage.getItem('usertype') === '1') {
      this.userType = 'ADMIN';
      this.getAllTrips();
    }
    else if (localStorage.getItem('userType') === '2' || localStorage.getItem('userType') === '3') {
      this.userType = localStorage.getItem('currentUser');
      this.getTripsByEmployeeId();
    }
    else {
      localStorage.removeItem('userType');
      localStorage.removeItem('currentUser');
      localStorage.removeItem('employeeId');
      this.route.navigate(['/login']);
    }
  }


  getAllTrips() {
    this.trips = [];
    this.service.getAllTrips()
      .pipe(first())
      .subscribe(
        data => {
          this.alertService.success('All Trip Details retrieved successfully', true);
          this.loading = false;
          this.trips = data.value.body;
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

  getTripsByEmployeeId() {
    this.trips = [];
    this.service.getTripsByUser(this.userId).pipe(first())
      .subscribe(
        data => {
          this.alertService.success('Trip Details retrieved successfully', true);
          this.loading = false;
          this.trips = data.value.body;          
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

  confirmRide(tripId) {
    this.service.confirmUserTrips(tripId, this.userId).pipe(first())
      .subscribe(
        data => {
          this.alertService.success('Trip confirmed', true);
          this.loading = false;
          this.trips = data.value.body;
          this.getAllTrips();
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }

  cancelRide(tripId) {
    this.service.cancelUserTrips(tripId, this.userId).pipe(first())
      .subscribe(
        data => {
          this.alertService.success('Trip cancelled', true);
          this.loading = false;
          this.trips = data.value.body;
          this.getAllTrips();
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }


}
