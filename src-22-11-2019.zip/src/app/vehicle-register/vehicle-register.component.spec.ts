import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { HttpClientTestingModule } from '@angular/common/http/testing' 

import { RegisterVehicleComponent } from './vehicle-register.component';
import { UserService } from '../services/user-service';
import { AlertService } from '../services/alert.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
class ServiceMock{

}

describe('RegisterVehicleComponent', () => {
    let component: RegisterVehicleComponent;
    let fixture: ComponentFixture<RegisterVehicleComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RegisterVehicleComponent],
            schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
            imports :[HttpClientTestingModule],
            providers:[
                {provide: UserService, useClass: ServiceMock},
                {provide: AlertService, useClass: ServiceMock},
                {provide: Router, useClass: ServiceMock}
            ]
           
            
        })
            .compileComponents().then(() => {
                fixture = TestBed.createComponent(RegisterVehicleComponent);
                component = fixture.componentInstance;
                //fixture.detectChanges();
            });
    }));


    it('should create',async(() => {
        //expect(component).toBeTruthy();
        expect(component.onSubmit()).toBeTruthy();

    }));
});
