
export class BookRide {
    Pickup: string;
    Drop: string;
    StartDateTime: Date;
    EndDateTime: Date;
    VehicleType: string;
    Contact: number;
    Amount: number;    
    VehicleId: number;
    Status: string;
    IsConfirmed: boolean;
    IsCancelled: boolean
    UserId: number;
}
