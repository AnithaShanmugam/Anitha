export class LoginModel {
    UserId: number;
    UserName: string;
    Password: string;
    FullName: string;
    Contact: number;
    UserType: number;
    EmployeeToken: string = '';
}
