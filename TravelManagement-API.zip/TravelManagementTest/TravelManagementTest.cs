using System;
using Xunit;

namespace TravelManagementTest
{
    public class TravelManagementTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
