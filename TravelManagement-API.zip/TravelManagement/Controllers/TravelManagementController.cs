﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using TravelManagement.DataModel;
using TravelManagement.Services;

namespace TravelManagement.Controllers
{
    [ApiController]
    [EnableCors("AllowAllHeaders")]
    [Route("api/v1/[controller]")]
    public class TravelManagementController : ControllerBase
    {

        private readonly ILogger<TravelManagementController> _logger;


        public readonly ITravelManagementService _travelManagementService;
        //private readonly CircuitBreakerPolicy<HttpResponseMessage> _breakerPolicy;
        //   public readonly ITokenGenerator _tokengenerator;

        //public TravelManagementController(ITravelManagementService tripManagementService, ILogger<TravelManagementController> logger,
        //    CircuitBreakerPolicy<HttpResponseMessage> breakerPolicy, ITokenGenerator tokenGenerator)
        //{

        /// <summary>
        /// TravelManagementController
        /// </summary>
        /// <param name="tripManagementService"></param>
        /// <param name="logger"></param>
        public TravelManagementController(ITravelManagementService tripManagementService, ILogger<TravelManagementController> logger)
        {

            this._travelManagementService = tripManagementService;
            this._logger = logger;
            //_breakerPolicy = breakerPolicy;
            //   this._tokengenerator = tokenGenerator;
        }

        /// <summary>
        /// GetAllTrips
        /// </summary>
        /// <returns></returns>
        [HttpGet("getAllTrips")]
        public List<RideSummary> GetAllTrips()
        {
            try
            {
                _logger.LogInformation("GetAllTrips method been called");
                var trips = _travelManagementService.GetAllTrips();
                if (trips != null)
                {
                    _logger.LogInformation("GetAllTrips method returns value");
                    return trips;
                }
                else
                {
                    _logger.LogWarning("GetAllTrips method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in GetAllTrips. Please check stack trace " + ex + "");
                throw ex;
            }

        }
        /// <summary>
        /// GetTripsbyId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet("getTripsbyId")]
        public List<BookRide> GetTripsbyId(int userId)
        {
            try
            {
                _logger.LogInformation("GetAllTrips method been called");
                var trips = _travelManagementService.GetTripByUserid(userId);
                if (trips != null)
                {
                    _logger.LogInformation("GetAllTrips method returns value");
                    return trips;
                }
                else
                {
                    _logger.LogWarning("GetAllTrips method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in GetAllTrips. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// GetAllUsers
        /// </summary>
        /// <returns></returns>
        [HttpGet("getAllUsers")]
        public List<UserSummary> GetAllUsers()
        {
            try
            {
                _logger.LogInformation("GetAllUsers method been called");
                var users = _travelManagementService.GetAllUsers();
                if (users != null)
                {
                    _logger.LogInformation("GetAllUsers method returns value");
                    return users;
                }
                else
                {
                    _logger.LogWarning("GetAllUsers method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in GetAllUsers. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// registerUser
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        // POST api/v1/RegisterUser
        [HttpPost("registerUser")]
        public string RegisterUser([FromBody] Users value)
        {
            try
            {
                _logger.LogInformation("RegisterUser method been called");
                var userId = _travelManagementService.RegisterUser(value);
                if (!String.IsNullOrEmpty(userId))
                {
                    _logger.LogInformation("RegisterUser method returns value");
                    return userId;
                }
                else
                {
                    _logger.LogWarning("RegisterUser method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in RegisterUser. Please check stack trace " + ex + "");
                throw ex;
            }
        }

        /// <summary>
        /// RegisterVehicle
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        // POST api/v1/RegisterVehicle
        [HttpPost("registerVehicle")]
        public String RegisterVehicle([FromBody] VehicleRegister value)
        {
            try
            {
                _logger.LogInformation("RegisterVehicle method been called");
                var vehicleId = _travelManagementService.RegisterVehicle(value);
                if (!String.IsNullOrEmpty(vehicleId))
                {
                    _logger.LogInformation("RegisterVehicle method returns value");
                    return vehicleId;
                }
                else
                {
                    _logger.LogWarning("RegisterVehicle method returns null value");
                    return "";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in RegisterVehicle. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// BookRide
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        //  POST api/v1/BookRide
        [HttpPost("bookRide")]
        public String BookRide([FromBody] BookRide value)
        {
            try
            {
                _logger.LogInformation("BookRide method been called");
                var tripId = _travelManagementService.BookRide(value);
                if (!String.IsNullOrEmpty(tripId))
                {
                    _logger.LogInformation("BookRide method returns  value");
                    return tripId;
                }
                else
                {
                    _logger.LogWarning("BookRide method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in BookRide. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// ConfirmTrip
        /// </summary>
        /// <param name="tripDetail"></param>
        /// <returns></returns>
        //get api/v1/CancelTrip
        [HttpPost("confirmTrip")]
        public string ConfirmTrip([FromBody] TripDetail tripDetail)
        {
            try
            {
                _logger.LogInformation("CancelTrip method been called");
                var trips = _travelManagementService.ConfirmRide(tripDetail.tripId, tripDetail.userId);
                if (trips != null)
                {
                    _logger.LogInformation("CancelTrip method returns  value");
                    return trips;
                }
                else
                {
                    _logger.LogWarning("CancelTrip method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in CancelTrip. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// CancelTrip
        /// </summary>
        /// <param name="tripDetail"></param>
        /// <returns></returns>
        //get api/v1/CancelTrip
        [HttpPost("cancelTrip")]
        public string CancelTrip([FromBody] TripDetail tripDetail)
        {
            try
            {
                _logger.LogInformation("CancelTrip method been called");
                var trips = _travelManagementService.CancelRide(tripDetail.tripId, tripDetail.userId);
                if (trips != null)
                {
                    _logger.LogInformation("CancelTrip method returns  value");
                    return trips;
                }
                else
                {
                    _logger.LogWarning("CancelTrip method returns null value");
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in CancelTrip. Please check stack trace " + ex + "");
                throw ex;
            }

        }

        /// <summary>
        /// Login
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns></returns>

        //  POST api/v1/BookRide
        [HttpPost("logIn")]
        public Users Login([FromBody] UserLoginDetails userDetails)
        {
            try
            {
                Users user;

                _logger.LogInformation("Login method been called");
                if (userDetails.UserName.Length > 0 && userDetails.Password.Length > 0)
                {
                    //    var value = _tokengenerator.Login(userName);
                    //if (value != "")
                    //{
                    user = _travelManagementService.CheckLogin(userDetails.UserName, userDetails.Password);
                    if (!String.IsNullOrEmpty(user.UserId.ToString()))
                    {
                        _logger.LogInformation("Login method returns  value");
                        return user;
                    }
                    else
                    {
                        _logger.LogWarning("Login method returns null value");
                        return null;
                    }
                    //}
                    //else
                    //{
                    //    return null;
                    //}
                }
                else
                {
                    return null;
                }                
            }
            catch (Exception ex)
            {
                _logger.LogError("Error Occured in Login. Please check stack trace " + ex + "");
                throw ex;
            }

        }


    }
}
