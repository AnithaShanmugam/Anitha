﻿using System.Collections.Generic;
using TravelManagement.DataModel;
using TravelManagement.Repository;

namespace TravelManagement.Services
{
    public class TravelmanagementService : ITravelManagementService
    {

        public readonly ITravelRepository travelRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="repository"></param>
        public TravelmanagementService(ITravelRepository repository)
        {
            travelRepository = repository;
        }
        /// <summary>
        /// GetAllTrips
        /// </summary>
        /// <returns></returns>
        public List<RideSummary> GetAllTrips()
        {
            return travelRepository.GetAllTrips();
        }

        /// <summary>
        /// GetTripByUserid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<BookRide> GetTripByUserid(int userId)
        {
            return travelRepository.GetTripByUserid(userId);
        }

        /// <summary>
        /// RegisterUser
        /// </summary>
        /// <param name="registerUser"></param>
        /// <returns></returns>
        public string RegisterUser(Users registerUser)
        {
            return travelRepository.RegisterUser(registerUser);
        }

        /// <summary>
        /// RegisterVehicle
        /// </summary>
        /// <param name="registerVehicle"></param>
        /// <returns></returns>
        public string RegisterVehicle(VehicleRegister registerVehicle)
        {
            return travelRepository.RegisterVehicle(registerVehicle);
        }

        /// <summary>
        /// BookRide
        /// </summary>
        /// <param name="rideDetail"></param>
        /// <returns></returns>
        public string BookRide(BookRide rideDetail)
        {
            return travelRepository.BookRide(rideDetail);
        }

        /// <summary>
        /// CancelRide
        /// </summary>
        /// <param name="tripId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string CancelRide(int tripId, int userId)
        {
            return travelRepository.CancelRide(tripId, userId);
        }

        /// <summary>
        /// ConfirmRide
        /// </summary>
        /// <param name="tripId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string ConfirmRide(int tripId, int userId)
        {
            return travelRepository.ConfirmRide(tripId, userId);
        }

        /// <summary>
        /// CheckLogin
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public Users CheckLogin(string userName, string password)
        {
            return travelRepository.CheckLogin(userName, password);
        }

        /// <summary>
        /// GetAllUsers
        /// </summary>
        /// <returns></returns>
        public List<UserSummary> GetAllUsers()
        {
            return travelRepository.GetAllUsers();
        }

    }
}
