﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TravelManagement;
using TravelManagement.DataModel;

namespace TravelManagement.Services
{
    public interface ITravelManagementService
    {
        List<RideSummary> GetAllTrips();

        List<BookRide> GetTripByUserid(int userId);

        string RegisterUser(Users registerUser);

        string RegisterVehicle(VehicleRegister registerVehicle);

        string BookRide(BookRide rideDetail);

        string CancelRide(int tripId, int userId);

        string ConfirmRide(int tripId, int userId);

        Users CheckLogin(string userName, string password);

        List<UserSummary> GetAllUsers();
    }
}
