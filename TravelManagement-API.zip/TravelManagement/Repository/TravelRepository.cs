﻿using System;
using System.Collections.Generic;
using System.Linq;
using TravelManagement;
using TravelManagement.DataModel;


namespace TravelManagement.Repository
{
    public class TravelRepository : ITravelRepository
    {

        public readonly TravelDBContext travelDBContext;

        /// <summary>
        /// TravelRepository
        /// </summary>
        /// <param name="dbContext"></param>
        public TravelRepository(TravelDBContext dbContext)
        {
            travelDBContext = dbContext;
        }

        /// <summary>
        /// GetAllTrips
        /// </summary>
        /// <returns></returns>
        public List<RideSummary> GetAllTrips()
        {
            List<RideSummary> trips = travelDBContext.BookRide.Select(x => new
                                      RideSummary
            {

                TripId = x.TripId,
                UserId = x.UserId,
                Amount = x.Amount,
                Contact = x.Contact,
                Drop = x.Drop,
                Pickup = x.Pickup,
                EndDateTime = x.EndDateTime,
                StartDateTime = x.StartDateTime,
                IsCancelled = x.IsCancelled,
                IsConfirmed = x.IsConfirmed,
                Status = x.Status,
                VehicleId = x.VehicleId,
                VehicleType = x.VehicleType,


            }).ToList();

            foreach (var groupItem in trips)
            {
                groupItem.VehicleNo = getVehicleNo(groupItem.VehicleId);
                groupItem.EmployeeName = getUserName(groupItem.UserId);

            }
            return trips;
        }

        /// <summary>
        /// getUserName
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public string getUserName(int UserId)
        {
            var userDetail = travelDBContext.Users.Where(x => x.UserId == UserId).FirstOrDefault();
            if (userDetail != null)
            {
                return userDetail.UserName;
            }
            else
            {
                return null;
            }

        }
        /// <summary>
        /// getVehicleNo
        /// </summary>
        /// <param name="VehicleId"></param>
        /// <returns></returns>
        public string getVehicleNo(int VehicleId)
        {
            var VehicleNo = travelDBContext.VehicleRegister.Where(x => x.VehicleId == VehicleId).FirstOrDefault();
            if (VehicleNo != null)
            {
                return VehicleNo.RegistrationNo;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// GetTripByUserid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<BookRide> GetTripByUserid(int userId)
        {
            var trips = travelDBContext.BookRide.Where(x => x.UserId == userId).ToList();
            if (trips != null)
            {
                return trips;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// RegisterUser
        /// </summary>
        /// <param name="registerUser"></param>
        /// <returns></returns>
        public string RegisterUser(Users registerUser)
        {
            try
            {

                travelDBContext.Add(registerUser);
                travelDBContext.SaveChanges();
                var userId = travelDBContext.Users.Count();
                return userId.ToString();
            }
            catch (Exception exception)
            {
                throw exception;
            }

        }

        /// <summary>
        /// RegisterVehicle
        /// </summary>
        /// <param name="registerVehicle"></param>
        /// <returns></returns>
        public string RegisterVehicle(VehicleRegister registerVehicle)
        {
            try
            {
                travelDBContext.Add(registerVehicle);
                travelDBContext.SaveChanges();
                var vehicleId = travelDBContext.VehicleRegister.Count();
                return vehicleId.ToString();
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// BookRide
        /// </summary>
        /// <param name="rideDetail"></param>
        /// <returns></returns>
        public string BookRide(BookRide rideDetail)
        {
            try
            {
                travelDBContext.Add(rideDetail);
                travelDBContext.SaveChanges();
                var tripId = travelDBContext.BookRide.Count();
                return tripId.ToString();
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        /// <summary>
        /// ConfirmRide
        /// </summary>
        /// <param name="tripId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string ConfirmRide(int tripId, int userId)
        {
            var trips = travelDBContext.BookRide.First(x => x.UserId == userId && x.TripId == Convert.ToInt32(tripId));
            if (trips != null)
            {
                trips.IsConfirmed = true;
                trips.IsCancelled = false;
                travelDBContext.SaveChanges();
                return trips.TripId.ToString();
            }
            else
            {
                return "Error Occured while update";
            }
        }

        /// <summary>
        /// CancelRide
        /// </summary>
        /// <param name="tripId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string CancelRide(int tripId, int userId)
        {
            var trips = travelDBContext.BookRide.First(x => x.UserId == userId && x.TripId == Convert.ToInt32(tripId));
            if (trips != null)
            {
                trips.IsConfirmed = false;
                trips.IsCancelled = true;
                travelDBContext.SaveChanges();
                return trips.TripId.ToString();
            }
            else
            {
                return "Error Occured while update";
            }
        }

        /// <summary>
        /// CheckLogin
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public Users CheckLogin(string userName, string password)
        {
            var user = travelDBContext.Users.First(x => x.UserName == userName && x.Password == password);
            return user;
        }

        /// <summary>
        /// GetAllUsers
        /// </summary>
        /// <returns></returns>
        public List<UserSummary> GetAllUsers()
        {
            List<UserSummary> users = travelDBContext.Users.Select(x => new
                                      UserSummary
            {
                UserId = x.UserId,
                UserName = x.UserName,
                UserType = x.UserType == 1 ? "Admin" : x.UserType == 2 ? "Employee" : "Guest",
                Contact = x.Contact
            }).ToList();
            return users;
        }

    }
}

