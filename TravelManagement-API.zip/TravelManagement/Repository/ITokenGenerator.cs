﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TravelManagement.Repository
{
    public interface ITokenGenerator
    {
        string Login(string userId);
    }
}
