﻿using System.Collections.Generic;
using TravelManagement.DataModel;

namespace TravelManagement.Repository


{
    public interface ITravelRepository
    {
        List<RideSummary> GetAllTrips();

        List<BookRide> GetTripByUserid(int userId);

        string RegisterUser(Users registerUser);

        string RegisterVehicle(VehicleRegister registerVehicle);

        string BookRide(BookRide rideDetail);

        Users CheckLogin(string userName, string password);

        string CancelRide(int tripId, int userId);

        string ConfirmRide(int tripId, int userId);

        List<UserSummary> GetAllUsers();
    }
}
