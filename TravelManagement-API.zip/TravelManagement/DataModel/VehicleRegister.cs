﻿namespace TravelManagement.DataModel
{
    public class VehicleRegister
    {
        public int VehicleId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string RegistrationNo { get; set; }

        public string VehicleType { get; set; }

        public string IdProof { get; set; }

        public string Contact { get; set; }

        public string Email { get; set; }
    }
}