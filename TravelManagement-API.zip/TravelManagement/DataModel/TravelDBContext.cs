﻿using Microsoft.EntityFrameworkCore;

namespace TravelManagement.DataModel
{
    public class TravelDBContext : DbContext
    {
        /// <summary>
        /// TravelDBContext
        /// </summary>
        /// <param name="options"></param>
        public TravelDBContext(DbContextOptions<TravelDBContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }

        public DbSet<BookRide> BookRide { get; set; }
        public DbSet<VehicleRegister> VehicleRegister { get; set; }

        public DbSet<Users> Users { get; set; }

        /// <summary>
        /// OnModelCreating
        /// </summary>
        /// <param name="builder"></param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<BookRide>().HasKey(t => t.TripId);
            builder.Entity<BookRide>().ToTable("BookRide");

            builder.Entity<Users>().HasKey(t => t.UserId);
            builder.Entity<Users>().ToTable("Users");

            builder.Entity<VehicleRegister>().HasKey(t => t.VehicleId);
            builder.Entity<VehicleRegister>().ToTable("VehicleRegister");

        }
    }
}
