﻿namespace TravelManagement.DataModel
{
    public class UserLoginDetails
    {
        public string UserName { get; set; }

        public string Password { get; set; }
    }
}
