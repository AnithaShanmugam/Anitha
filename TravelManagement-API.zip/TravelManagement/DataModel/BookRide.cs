﻿using System;

namespace TravelManagement.DataModel
{
    /// <summary>
    /// BookRide
    /// </summary>
    public class BookRide
    {
        public int TripId { get; set; }

        public string Pickup { get; set; }

        public string Drop { get; set; }

        public DateTime StartDateTime { get; set; }

        public DateTime EndDateTime { get; set; }

        public string VehicleType { get; set; }

        public int Contact { get; set; }

        public int Amount { get; set; }

        //public string EmployeName { get; set; }

        public int VehicleId { get; set; }
       
        public string Status { get; set; }

        public Boolean IsConfirmed { get; set; }

        public Boolean IsCancelled { get; set; }

        public int UserId { get; set; }
    }
}