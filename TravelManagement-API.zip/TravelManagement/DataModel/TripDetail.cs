﻿
namespace TravelManagement.DataModel
{
    public class TripDetail
    {       
            public int userId { get; set; }

            public int tripId { get; set; }

    }
}
