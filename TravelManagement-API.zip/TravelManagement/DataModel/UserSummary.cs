﻿namespace TravelManagement.DataModel
{
    public class UserSummary
    {

        public int UserId { get; set; }
        public string UserName { get; set; }

        public string FullName { get; set; }

        public int Contact { get; set; }

        public string UserType { get; set; }


    }
}
