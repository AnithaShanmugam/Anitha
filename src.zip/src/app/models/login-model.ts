export class LoginModel {
    employeeId: number;
    userName: string;
    password: string;
    fullName: string;
    contact: string;
    employeeType: string;
    employeeToken: string;
}
