import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from '../../services/authentication.service';
import { LoginModel } from '../models/login-model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  returnUrl: string = '';
  LoginModel: LoginModel = new LoginModel();
  //private _loginservice;

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router, private loginservice: AuthenticationService) {
   
    //localStorage.removeItem('currentUser');
    //localStorage.removeItem('userType');
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });    

    //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }




  //onSubmit() {

  //  this.submitted = true;

  //  if (this.loginForm.invalid) {
  //    return;
  //  }
  //  this.service.login(this.f.username.value, this.f.password.value).then(data => {
  //    localStorage.setItem('currentUser', data.userName);
  //    localStorage.setItem('employeeId', data.employeeId);
  //    localStorage.setItem('userType', data.employeeType);
  //    this.router.navigate(['/trips']);
  //  }).catch(error => {
  //    alert('Error occured while login - ' + error);
  //  });
  //}
  onSubmit() {
    this.loginservice.validateLoginUser(this.LoginModel).subscribe(
      response => {
        if (response == "") {
          //let config = new MatSnackBarConfig();
          //config.duration = this.setAutoHide ? this.autoHide : 0;
          //config.verticalPosition = this.verticalPosition;

          //this.snackBar.open("Invalid Username and Password", this.action ? this.actionButtonLabel : undefined, config);

          this.router.navigate(['Login']);
        }

        if (response.usertype == "1") {
          //let config = new MatSnackBarConfig();
          //config.duration = this.setAutoHide ? this.autoHide : 0;
          //config.verticalPosition = this.verticalPosition;

          //this.snackBar.open("Logged in Successfully", this.action ? this.actionButtonLabel : undefined, config);

          this.router.navigate(['/Admin/Dashboard']);
        }

        if (response.usertype == "2") {
          //let config = new MatSnackBarConfig();
          //config.duration = this.setAutoHide ? this.autoHide : 0;
          //config.verticalPosition = this.verticalPosition;

          //this.snackBar.open("Logged in Successfully", this.action ? this.actionButtonLabel : undefined, config);
          this.router.navigate(['/User/Dashboard']);
        }
      });

  }
}
