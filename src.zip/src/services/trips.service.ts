// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';

// @Injectable({
//   providedIn: 'root'
// })
// export class TripsService {

//   private httpOptions = {
//     headers : new HttpHeaders({'Content-Type': 'application/json'})
//    };
//    baseUrl: string = 'http://localhost:5000/api/v1/trips/';
//    constructor(private http: HttpClient) { }
 
//    getAllTrips(): Promise<any[]> {
//      return this.http.get<any[]>(this.baseUrl, this.httpOptions).toPromise().then(res => {
//         return res as any[];
//      }).catch(error => {
//         return [];
//         throw error;
//      });
//    }

//    getTripsByUser(userID: number): Promise<any[]> {
//     return this.http.get<any[]>(this.baseUrl + userID, this.httpOptions).toPromise().then(res => {
//       return res as any[];
//    }).catch(error => {
//       return [];
//       throw error;
//    });
//    }
// }
