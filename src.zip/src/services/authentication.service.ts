import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { LoginModel } from '../app/models/login-model';
import { Observable, throwError } from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  baseUrl = 'http://localhost:5001/api/auth/';

  constructor(private httpClient: HttpClient) { }

  private apiUrl = environment.apiEndpoint + "/auth";

  //login(userName: string, password: string): Promise<any>{
  //  let user: User = new User();
  //  user.userName = userName;
  //  user.password = password;
  //  return this.http.post<any>(this.baseUrl + 'login', user, this.httpOptions).toPromise().then(users =>{
  //    if (users != null && users.EmployeeToken != null) {
  //      localStorage.setItem('currentUser', users.UserName);
  //      localStorage.setItem('currentUserType', user.employeeType);
  //    }
  //    return users;
  //  }).catch(error=>{
  //    throw error;
  //  });
  //}

  //logout(){
  //  localStorage.removeItem('currentUser');
  //}


  public validateLoginUser(loginmodel: LoginModel) {

    return this.httpClient.post<any>(this.apiUrl, loginmodel, this.httpOptions)
      .pipe(tap(data => {
        console.log(data);

        if (data.token != null) {
          if (data.usertype === 2) {
            // store username and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser',
              JSON.stringify({
                username: loginmodel.userName, token: data.token, UserId: data.userId,
                usertype: data.usertype, firstName: data.firstName, lastName: data.lastName
              }));
          } else if (data.usertype === 1) {
            // store username and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('AdminUser',
              JSON.stringify({
                username: loginmodel.userName, token: data.token, usertype: data.usertype, UserId: data.userId,
                firstName: data.firstName, lastName: data.lastName
              }));
          }
          // return true to indicate successful login
          return data;
        } else {
          // return false to indicate failed login
          return null;
        }
      }),
        catchError(this.handleError)
      );
  }

  LogoutUser() {
    localStorage.removeItem('currentUser');
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  };

}
